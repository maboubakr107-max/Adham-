# Adham Barber Premium
Next.js + Supabase starter. انسخ .env.example إلى .env.local، ضع مفاتيح Supabase، نفذ supabase/schema.sql ثم npm install && npm run dev.
مهم: هذه قاعدة بداية فعلية وليست نظام إنتاج مكتمل؛ يجب إضافة Supabase Auth وStorage وRLS الكامل قبل النشر.
